function startGame() {
  alert('게임이 시작됩니다!');
  // 여기서 본격적인 게임 로직을 연결하면 돼요.
}